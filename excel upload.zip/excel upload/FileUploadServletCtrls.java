package com.vaccination.ctrls.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.el.parser.ParseException;

/*import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;*/

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.vaccination.db.DbSettings;
import com.vaccination.model.VaccinationGiven;



public class FileUploadServletCtrls {
	
	//int vsID ;
	int vID ;
	int userID ;
//	int cityID ;
	public String message;
	public boolean addVaccinationBatchQuerytoDb(String tempFilePath, ServletContext context) {
		boolean checkCondition = false;
		Connection connection = null;
		ComboPooledDataSource comboPooledDataSource = null;
		Statement callableStatement = null;
		message = "Successfully uploaded";
		try {
			
			comboPooledDataSource = (ComboPooledDataSource) context.getAttribute(DbSettings.comboPooledDataSource);
			connection = comboPooledDataSource.getConnection();
			
			String[] qr = createQueryListArray(tempFilePath);
			callableStatement = (Statement) connection.createStatement();
			for (String query : qr) {
				callableStatement.addBatch(query);
			}
			callableStatement.executeBatch();
			checkCondition = true;

		} catch (ParseException | SQLException e) {
			// TODO Auto-generated catch block
			//out.print("DATA BASE..... " + e.getMessage());
			e.printStackTrace();
			message = e.getMessage();
			checkCondition = false;
		}

		// Closing DB connection and statements
		finally {
			
			if (comboPooledDataSource != null)
				try {
					//callableStatement.close();
				} catch (Exception e) {
					e.printStackTrace();
				}


			if (callableStatement != null)
				try {
					callableStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

		return checkCondition;

	}
	
	public String createTempFile(HttpServletRequest request,ServletContext context) 
	{
		String filePath ="";
		FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        
       
        List items;
		try {
			 
			items = upload.parseRequest(request);
			
			Iterator iterator = items.iterator();
	        while (iterator.hasNext()) {
	        	
	            FileItem item = (FileItem) iterator.next();
	            
	            if( item.isFormField() )
	            {
	            	
	              String fieldName = item.getFieldName();
	              if(fieldName.equals("vID")) 
	              {
	           	 
	            	  	this.vID = Integer.parseInt(item.getString());
	             }
	             /* else if(fieldName.equals("vsID")) 
	              {
	            	 
	            	  	this.vsID = Integer.parseInt(item.getString());
	            	  	
	              } */
	              else if(fieldName.equals("userID")) 
	              {
	            	 
	            	  	this.userID = Integer.parseInt(item.getString());
	             }
	             /* else if(fieldName.equals("cityID")) 
	              {
	            	  
	            	  	this.cityID = Integer.parseInt(item.getString());
	              } */
//	              out.write(this.vID+".....Form Values Name...."+this.vsID);
//	              out.write("<br/>");
	              
	            }

	            if (!item.isFormField()) {
	            	
	                String fileName = item.getName();
	//               out.write("File Name...."+fileName);
	             
	                String root = context.getRealPath("/");
	                File path = new File(root + "/uploads");
	                if (!path.exists()) {
	                	 
	                    boolean stat = path.mkdirs();
	                }
//	                out.write("<br/>");
//	                out.write(path+".....File PATH ...."+path.exists());
	                filePath = path + "/" + fileName;
	                File uploadedFile = new File(path + "/" + fileName);
	                System.out.println(uploadedFile.getAbsolutePath());
//	                out.write("<br/>");
//	                out.write("File PATH Exist...."+path.exists());

						item.write(uploadedFile);
					
	              
	                
	            }
	        }
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			message = e.getMessage();
//			out.write("<br/>");
//            out.write("File PATH Error...."+e.getMessage());
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//			out.write("<br/>");
//            out.write("File PATH Error1...."+e.getMessage());
			message = e.getMessage();
		} 
        return filePath;
	}
	
	
	
	
	public String[] createQueryListArray(String filePath)
			throws ParseException {

		String[] queries;
		 
		//out.write("Start Creating the quwry...."+filePath);

		try {
			
			File file = new File(filePath);
			InputStream fis = new FileInputStream(file);

			/*
			 * POIFSFileSystem fs = new POIFSFileSystem(fis); HSSFWorkbook wb = new
			 * HSSFWorkbook(fs); HSSFSheet sheet = wb.getSheetAt(0);
			 */
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();
			queries = new String[rowCount + 1];
			
			//out.write("....Reading Excel...." + rowCount);
			int rowIndex = 0;
			/*
			 * queries = new String[rowCount]; for (int i = 1; i <= sheet.getLastRowNum();
			 * i++) { row = sheet.getRow(i); int uID = (int)
			 * row.getCell(0).getNumericCellValue(); int vsID = (int)
			 * row.getCell(1).getNumericCellValue(); String name =
			 * row.getCell(2).getStringCellValue(); String address =
			 * row.getCell(3).getStringCellValue(); int mob = (int)
			 * row.getCell(4).getNumericCellValue(); String mobile = Integer.toString(mob);
			 * 
			 * String emailid = row.getCell(5).getStringCellValue(); int age = (int)
			 * row.getCell(6).getNumericCellValue(); String gender =
			 * row.getCell(7).getStringCellValue(); int cityID = (int)
			 * row.getCell(8).getNumericCellValue(); String onDate =
			 * row.getCell(9).getStringCellValue(); int vID = (int)
			 * row.getCell(10).getNumericCellValue();
			 * 
			 * queries[rowIndex] =
			 * "INSERT INTO vaccination_given (uID, vsID, name, address, mobile, emailid, age, gender, cityID, onDate, vID) VALUES ('"
			 * + uID + "','" + vacc.getVsID() + "','" + name + "','" + address + "','" +
			 * mobile + "','" + emailid + "','" + age + "','" + gender + "','" + cityID +
			 * "','" + onDate + "','" + vacc.getvID() + "')"; rowIndex++; }
			 */

			String cellValues = "";
			
			int intValue;
			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
			
				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				
			//	cellValues = this.vsID + "," + this.vID + ","+this.userID + "," + this.cityID + ",";
				cellValues = this.vID + ","+this.userID + "," ;
				
				while (cellIterator.hasNext()) {
					
					Cell cell = cellIterator.next();
					 
					// Check the cell type and format accordingly
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							
					        //out.write(cell.getStringCellValue()+"....Row No.: " + cell.getNumericCellValue()+ " " + 
					        		//cell.getDateCellValue());
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							String formattedDate = formatter.format(cell.getDateCellValue());
							//out.write("Cell value is date....."+formattedDate);
					        cellValues += "'" + formattedDate + "',";
					       
					    }else 
					    {
					    		intValue = (int) cell.getNumericCellValue();
					    		cellValues += "" + intValue + ",";
					    		
					    }
						
						
						break;
					case Cell.CELL_TYPE_STRING:
						cellValues += "'" + cell.getStringCellValue() + "',";
						
						break;
					} 
				}
				if (cellValues.endsWith(",")) {
					cellValues = cellValues.substring(0, cellValues.length() - 1);
					
				}
				queries[rowIndex] = "INSERT INTO vaccination_given (vID, uID, child_name, aadhar_number, mobile, reported_location, dob, onDate, ward, location_type, Mother_name,pincode) "
						+ "VALUES( " + cellValues + ")";
				
		
				//out.write(rowIndex + "....CELL Contents..-----====" + queries[rowIndex]);
				rowIndex++;
			}
			//out.write(queries.toString() + "....File Parsing Completed...." + queries.length);

			return queries;
		} catch (IOException e) {
			//out.write(e.toString() + "....File Exception...." + e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
			message = e.getMessage();
		}

		return null;

	}
		

}
