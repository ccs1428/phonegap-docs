package com.vaccination.api.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;*/

import com.google.gson.Gson;
import com.vaccination.common.CommonStringUtils;
import com.vaccination.common.CommonStrings;
import com.vaccination.ctrls.admin.FileUploadServletCtrls;
import com.vaccination.model.ReturnMessage;

/**
 * Servlet implementation class FileUploadServletApi
 */
@WebServlet("/FileUploadServletApi")
public class FileUploadServletApi extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileUploadServletApi() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String outPutString = null;
		String strFileName = null;
		boolean isOperationDone = false;

		CommonStringUtils commonStringUtils = new CommonStringUtils();
		FileUploadServletCtrls ctrl = new FileUploadServletCtrls();
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		response.setContentType(CommonStrings.TEXT_CONTENT_TYPE);
//		 response.setContentType("text/html");
//		 PrintWriter out = response.getWriter();
//		 out.write("<html><head></head><body>");
//
//		 out.write("File Upload ....");
		if (isMultipart) {
			strFileName = ctrl.createTempFile(request, getServletContext());
			if (strFileName != null)
				
				isOperationDone = ctrl.addVaccinationBatchQuerytoDb(strFileName, getServletContext());
		}
		ReturnMessage mess = new ReturnMessage();
		if (isOperationDone) {
			mess.setMessage(ctrl.message);
			mess.setStatus("1");
		} else {
			mess.setMessage(ctrl.message);
			mess.setStatus("-1");
		}
		outPutString = new Gson().toJson(mess);
		
		
		commonStringUtils.processOutPut(response, outPutString);

	}

}
