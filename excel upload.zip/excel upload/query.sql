DELIMITER $$

CREATE DEFINER=`ima`@`%` PROCEDURE `get_VaccinationDetailsByUserForExcel`(
IN reqType VARCHAR(2),
IN d_userID INT,
IN d_vID INT,
IN fromDate VARCHAR(255),
IN toDate VARCHAR(255)
)
BEGIN

if(reqType = 'A') THEN
		select  distinct vg.vID, vm.name as vaccinationName, vg.uID, um.name as userName ,vg.child_name, vg.aadhar_number, vg.mobile, vg.reported_location, vg.dob,  DATE_FORMAT(vg.onDate, "%Y/%m/%d") as onDate ,vg.ward, 
vg.location_type, vg.Mother_name, vg.pincode from ima.vaccination_given as vg 
inner join vaccination_master as vm on vg.vID = vm.idvaccination inner join user_master as um 
on um.userID = vg.uID where DATE_FORMAT(onDate, "%Y/%m/%d") BETWEEN CURDATE() - INTERVAL 1 YEAR AND CURDATE();
END IF;

 IF(reqType = 'U') THEN
		select  distinct vg.vID, vm.name as vaccinationName, vg.uID,um.name as userName,vg.child_name, vg.aadhar_number, vg.mobile, vg.reported_location, vg.dob,  DATE_FORMAT(vg.onDate, "%Y/%m/%d") as onDate ,vg.ward, 
vg.location_type, vg.Mother_name, vg.pincode from ima.vaccination_given as vg 
inner join vaccination_master as vm on vg.vID = vm.idvaccination inner join user_master as um 
on um.userID = vg.uID where vg.uID = d_userID and DATE_FORMAT(onDate, "%Y/%m/%d") BETWEEN CURDATE() - INTERVAL 1 YEAR AND CURDATE();
END IF;

 IF(reqType = 'V') THEN

		select  distinct vg.vID, vm.name as vaccinationName, vg.uID,um.name as userName,vg.child_name, vg.aadhar_number, vg.mobile, vg.reported_location, vg.dob,  DATE_FORMAT(vg.onDate, "%Y/%m/%d") as onDate ,vg.ward, 
vg.location_type, vg.Mother_name, vg.pincode from ima.vaccination_given as vg 
inner join vaccination_master as vm on vg.vID = vm.idvaccination inner join user_master as um 
on um.userID = vg.uID and vg.vID = d_vID and DATE_FORMAT(onDate, "%Y/%m/%d") BETWEEN CURDATE() - INTERVAL 1 YEAR AND CURDATE();
END IF;

 IF (reqType = 'D') THEN

		select distinct  vg.vID, vm.name as vaccinationName, vg.uID, um.name as userName,vg.child_name, vg.aadhar_number, vg.mobile, vg.reported_location, vg.dob,  DATE_FORMAT(vg.onDate, "%Y/%m/%d") as onDate ,vg.ward, 
vg.location_type, vg.Mother_name, vg.pincode from ima.vaccination_given as vg 
inner join vaccination_master as vm on vg.vID = vm.idvaccination inner join user_master as um 
on um.userID = vg.uID where DATE_FORMAT(onDate, "%Y/%m/%d") between DATE_FORMAT(fromDate, "%Y/%m/%d") and DATE_FORMAT(toDate, "%Y/%m/%d");


END IF;
END